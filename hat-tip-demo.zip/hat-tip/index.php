<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Hat Tip | JDM Digital Demo</title>
	<meta name="description" content="A super-simple, super-light notification bar using jQuery and British humor." />
    <meta name="author" content="JDM Digital, Etho, and Performance Scoring" />
	
	<link rel="canonical" href="https://jdmdigital.co/demo/hat-tip/" />
	
	<link rel="dns-prefetch" href="//y3k8i7n6.stackpathcdn.com" />
	<link rel="preconnect" href="https://cdn.jsdelivr.net" />
	<link rel="preconnect" href="https://code.highcharts.com" />
	
	<!-- Add Favicons -->
	<link rel="icon" href="https://y3k8i7n6.stackpathcdn.com/wp-content/uploads/cropped-jdm10-site-icon-12-32x32.png" sizes="32x32">
	<link rel="icon" href="https://y3k8i7n6.stackpathcdn.com/wp-content/uploads/cropped-jdm10-site-icon-12-192x192.png" sizes="192x192">
	<link rel="apple-touch-icon" href="https://y3k8i7n6.stackpathcdn.com/wp-content/uploads/cropped-jdm10-site-icon-12-180x180.png">
	<meta name="msapplication-TileImage" content="https://y3k8i7n6.stackpathcdn.com/wp-content/uploads/cropped-jdm10-site-icon-12-270x270.png"> 
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
	<!--<link href="css/hat-tip.css" rel="stylesheet" />-->
	<link href="css/style-global.css?v=9" rel="stylesheet" />
</head>

<body class="bg-light locked">
	<div class="logged-out form-signin w-100 m-auto">
		<form id="signin">
			<h1 class="h3 mb-3">Hat Tip Demo</h1>
			<p class="lead">You can enter anything.<br>It's fake.</p>
			<div class="form-floating">
				<input type="text" class="form-control" id="charitychart-username" name="charitychart-username" placeholder="name@example.com" autocomplete="username" value="">
				<label for="charitychart-username">Email address</label>
			</div>
			<div class="form-floating">
				<input type="password" class="form-control" id="charitychart-password" name="charitychart-password" placeholder="Password" autocomplete="current-password" value="">
				<label for="charitychart-password">Password</label>
			</div>
			<button class="w-100 btn btn-lg btn-primary" type="submit">Login<span class="icon-login ms-2"></span></button>
			<p><small>This is fake. It's a demo. Nothing is stored.</small></p>
			<p class="mt-5 mb-3 text-muted">&copy; <?php echo date('Y'); ?> JDM Digital</p>
		</form>
	</div>
	<div class="logged-in">
		<header class="cc-header py-3 d-flex align-items-stretch border-bottom sticky-top">
			<div class="container-fluid d-flex align-items-center">
				<h1 class="d-flex align-items-center fs-4 text-white fw-bold mb-0">Hat<span class="fw-light" style="margin-left:2px;">Tip</span></h1>
				<a href="https://github.com/jdmdigital/hat-tip" class="ms-auto link-light">GitHub</a>
			</div>
		</header>
		<main>
			<section class="py-5 text-center container-fluid">
				<h2 class="display-1">Demo</h2>
				<p class="lead">A super-simple, super-light notification bar using jQuery and British humor.</p>
				<p><a href="https://github.com/jdmdigital/hat-tip" class="btn btn-primary me-3">GitHub Repo</a><a href="#" id="refresh" class="btn btn-secondary">Refresh</a></p>
			</section>
			<div class="py-4 bg-light container-fluid">
				<div class="container" style="max-width:1140px">
					<div class="row mb-4">
						<div class="col-12">
							<p>In cases when you don't really want notifications getting in the way of the every day use of your application, Toasts and Modals are literally the opposite. We wanted a basic banner notification. We'll be building on this over time, but here's MVP.</p>
							<h3 class="mt-4">Usage</h3>
							<p>Simply include the <code>hat-tip.js</code> in your project (or copy the raw code out), add the css you'll find in <code>hat-tip.css</code>, and put the following mark-up at the bottom of your page.</p>
<pre class="highlight">
&lt;div id=&quot;hattip&quot; role=&quot;alert&quot;&gt;<br>&nbsp;&nbsp;&lt;span id=&quot;msg&quot;&gt;&lt;/span&gt;<br>&nbsp;&nbsp;&lt;button type=&quot;button&quot; aria-label=&quot;Close&quot;&gt;&lt;span aria-hidden=&quot;true&quot;&gt;&amp;times;&lt;/span&gt;&lt;/button&gt;<br>&lt;/div&gt;
</pre>
							<p>You'll find all the details and options on the <a href="https://github.com/jdmdigital/hat-tip/blob/main/README.md">GitHub Repo readme file</a>.
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-12 d-none">
						<div class="card shadow-sm">
							<div class="card-body">
								<button type="button" class="btn btn-sm btn-outline-secondary float-end chart-refresh" data-refresh="chart-bellcurve"><span class="icon-loop"></span><span class="d-none d-lg-inline ms-2">Render</span></button>
								<h3 class="card-title">Bell Curve Example</h3>
								<div id="chart-bellcurve" class="charts"></div>
							</div>
						</div>
					</div>
					<div class="col-12 col-lg-6">
						<div class="card shadow-sm">
							<div class="card-body">
								<button type="button" class="btn btn-sm btn-outline-secondary float-end chart-refresh" data-refresh="chart-funnel"><span class="icon-loop"></span><span class="d-none d-lg-inline ms-2">Render</span></button>
								<h3 class="card-title">3D Funnel</h3>
								<div id="chart-funnel" class="charts"></div>
							</div>
						</div>
					</div>
					<div class="col-12 col-lg-6">
						<div class="card shadow-sm">
							<div class="card-body">
								<button type="button" class="btn btn-sm btn-outline-secondary float-end chart-refresh" data-refresh="chart-pie"><span class="icon-loop"></span><span class="d-none d-lg-inline ms-2">Render</span></button>
								<h3 class="card-title">3D Pie</h3>
								<div id="chart-pie" class="charts"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<footer class="text-muted py-3">
			<div class="container-fluid">
				<div class="row">
					<div class="col-6">
						<p class="mb-0">&copy; <?php echo date('Y'); ?> JDM Digital</p>
					</div>
					<div class="col-6 text-end">
						<ul class="list-inline">
							<li class="list-inline-item"><a href="https://jdmdigital.co/about/">About</a></li>
							<li class="list-inline-item"><a href="https://jdmdigital.co/about/">Terms</a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
	</div>
	<!--<div id="hattip" role="alert">
		<span id="msg"></span>
		<button type="button" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	</div>-->
	
	<script src="js/jquery-3.6.1.min.js" type="text/javascript"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
	
	<script src="https://code.highcharts.com/highcharts.js"></script>
	<script src="https://code.highcharts.com/highcharts-3d.js"></script>
	<script src="https://code.highcharts.com/modules/cylinder.js"></script>
	<script src="https://code.highcharts.com/modules/funnel3d.js"></script>
	<script src="https://code.highcharts.com/modules/histogram-bellcurve.js"></script>
	<script src="https://code.highcharts.com/modules/exporting.js"></script>
	<script src="https://code.highcharts.com/modules/export-data.js"></script>
	<script src="https://code.highcharts.com/modules/accessibility.js"></script>
	<script src="js/hat-tip-bundle.js" type="text/javascript"></script>
	<script src="js/functions.js?v=8" type="text/javascript"></script>
	
	<script> 
		jQuery(document).ready(function(){
			setTimeout(function() {
				hattip_fire('Top of the morning to ya!', 'ht-default');
			}, 1200);
			
			setTimeout(function() {
				hattip_fire('Just <b>click login</b> to see the full demo.', 'ht-default');
			}, 4000);

			setTimeout(function() {
				hattip_fire('Pub closed? <b>Nightmare!</b>', 'ht-danger');
			}, 16000);

			setTimeout(function() {
				hattip_fire('Pub\'s open! <b>Ideal.</b>', 'ht-success');
			}, 19000);
			
			setTimeout(function() {
				hattip_fire('Fancy a clicking on some of them buttons?', 'ht-default');
			}, 30000);
			
			setTimeout(function() {
				hattip_fire('Include, call the function, and Bob\'s your uncle.', 'ht-default');
			}, 55000);
			
			setTimeout(function() {
				hattip_fire('You\'re not all bum and parsley, are you?', 'ht-default');
			}, 85000);
		});
	</script>
</body>
</html>