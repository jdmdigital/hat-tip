$( document ).ready(function() {
		
	// Bell Curve Chart
	var bellData = [3.5, 3, 3.2, 3.1, 3.6, 3.9, 3.4, 3.4, 2.9, 3.1, 3.7, 3.4, 3, 3, 4,
    4.4, 3.9, 3.5, 3.8, 3.8, 3.4, 3.7, 3.6, 3.3, 3.4, 3, 3.4, 3.5, 3.4, 3.2,
    3.1, 3.4, 4.1, 4.2, 3.1, 3.2, 3.5, 3.6, 3, 3.4, 3.5, 2.3, 3.2, 3.5, 3.8, 3,
    3.8, 3.2, 3.7, 3.3, 3.2, 3.2, 3.1, 2.3, 2.8, 2.8, 3.3, 2.4, 2.9, 2.7, 2, 3,
    2.2, 2.9, 2.9, 3.1, 3, 2.7, 2.2, 2.5, 3.2, 2.8, 2.5, 2.8, 2.9, 3, 2.8, 3,
    2.9, 2.6, 2.4, 2.4, 2.7, 2.7, 3, 3.4, 3.1, 2.3, 3, 2.5, 2.6, 3, 2.6, 2.3,
    2.7, 3, 2.9, 2.9, 2.5, 2.8, 3.3, 2.7, 3, 2.9, 3, 3, 2.5, 2.9, 2.5, 3.6,
    3.2, 2.7, 3, 2.5, 2.8, 3.2, 3, 3.8, 2.6, 2.2, 3.2, 2.8, 2.8, 2.7, 3.3, 3.2,
    2.8, 3, 2.8, 3, 2.8, 3.8, 2.8, 2.8, 2.6, 3, 3.4, 3.1, 3, 3.1, 3.1, 3.1, 2.7,
    3.2, 3.3, 3, 2.5, 3, 3.4, 3];
	
	function renderChartBell() {
	
		Highcharts.chart('chart-bellcurve', {
			title: {
				text: ''
			},
			credits: {
				enabled: false
			},
			xAxis: [{
				title: {
					text: 'Data'
				},
				alignTicks: false
			}, {
				title: {
					text: 'Bell curve'
				},
				alignTicks: false,
				opposite: true
			}],

			yAxis: [{
				title: { text: 'Data' }
			}, {
				title: { text: 'Bell Curve' },
				opposite: true
			}],

			series: [{
				name: 'Bell curve',
				type: 'bellcurve',
				xAxis: 1,
				yAxis: 1,
				baseSeries: 1,
				zIndex: -1
			}, {
				name: 'Data',
				type: 'scatter',
				data: bellData,
				accessibility: {
					exposeAsGroupOnly: true
				},
				marker: {
					radius: 3
				}
			}]
		});
	}
	
	function renderChartFunnel() {
		// Set up the chart
		Highcharts.chart('chart-funnel', {
			chart: {
				type: 'funnel3d',
				options3d: {
					enabled: true,
					alpha: 10,
					depth: 50,
					viewDistance: 50
				}
			},
			credits: {
				enabled: false
			},
			title: {
				text: ''
			},
			plotOptions: {
				series: {
					dataLabels: {
						enabled: true,
						format: '<b>{point.name}</b> ({point.y:,.0f})',
						allowOverlap: true,
						y: 10
					},
					neckWidth: '30%',
					neckHeight: '25%',
					width: '80%',
					height: '80%'
				}
			},
			series: [{
				name: 'Unique users',
				data: [
					['Website visits', 10654],
					['Downloads', 4064],
					['Requested price list', 2987],
					['Invoice sent', 776],
					['Finalized', 546]
				]
			}]
		});
	}
	
	function renderChartPie() {
		Highcharts.chart('chart-pie', {
			chart: {
				type: 'pie',
				options3d: {
					enabled: true,
					alpha: 45,
					beta: 0
				}
			},
			credits: {
				enabled: false
			},
			title: {
				text: ''
			},
			accessibility: {
				point: {
					valueSuffix: '%'
				}
			},
			tooltip: {
				pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
			},
			plotOptions: {
				pie: {
					allowPointSelect: true,
					cursor: 'pointer',
					depth: 35,
					dataLabels: {
						enabled: true,
						format: '{point.name}'
					}
				}
			},
			series: [{
				type: 'pie',
				name: 'Share',
				data: [
					['Samsung', 23],
					['Xiaomi', 12],
					{
						name: 'Apple',
						y: 18,
						sliced: true,
						selected: true
					},
					['Oppo*', 9],
					['Vivo', 8],
					['Others', 30]
				]
			}]
		});
	}
	// Fake Data Pull
	function pullData() {
		setTimeout(function() {
			renderChartBell();
		}, 480);
		setTimeout(function() {
			renderChartFunnel();
		}, 700);
		setTimeout(function() {
			renderChartPie();
		}, 650);
	}
	$('#refresh').click(function() {
		pullData();
		hattip_fire('All chart data refreshed successfully.','alert-success');
	});
	// Login
	$('form#signin').submit(function(evt) {
		evt.preventDefault();
		$('.form-signin').fadeOut(function() { 
			$('body').removeClass('locked');
			pullData();
		});
	});
	// Logout
	$('header #logout').click(function(evt) {
		evt.preventDefault();
		$('body').addClass('locked');
		$('.logged-in').fadeOut(function() {
			$('.form-signin').fadeIn();
		});
	});
	
	// Individual Chart Refresh
	$('.chart-refresh').click(function() {
		var toRefresh = $(this).data('refresh');
		var thisCard = $(this).parent().parent();
		$(thisCard).addClass('refreshing');
		if (toRefresh == 'chart-pie') {
			setTimeout(function() {
				$(thisCard).removeClass('refreshing');
				renderChartPie();
				hattip_fire('Pie chart rendered.');
			}, 425);
		} else if (toRefresh == 'chart-funnel') {
			setTimeout(function() {
				$(thisCard).removeClass('refreshing');
				renderChartFunnel();
				hattip_fire('Funnel chart rendered.');
			}, 525);
		} else if (toRefresh == 'chart-bellcurve') {
			setTimeout(function() {
				$(thisCard).removeClass('refreshing');
				renderChartBell();
				hattip_fire('Bellcurve chart rendered');
			}, 675);
		}
	});
	
});