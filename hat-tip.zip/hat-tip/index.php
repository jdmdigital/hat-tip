<!doctype html>
<html>
<head>
	<meta name="robots" content="noindex" />
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Hat Tip | JDM Digital Demo</title>
	<meta name="description" content="A super-simple, super-light notification bar using jQuery and British humor." />
    <meta name="author" content="JDM Digital, Etho, and Performance Scoring" />
	
	<link rel="canonical" href="https://jdmdigital.co/demo/hat-tip/" />
	
	<link rel="preconnect" href="https://cdn.jsdelivr.net" />
	<link rel="preconnect" href="https://code.highcharts.com" />
	<link rel="preconnect" href="https://fonts.googleapis.com" />
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
	
	<!-- Add Favicons -->
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
	<link href="css/hat-tip.css" rel="stylesheet" />
	<link href="css/style-global.css?v=8" rel="stylesheet" />
</head>

<body class="bg-light">
	<div class="logged-in">
		<header class="cc-header py-3 d-flex align-items-stretch border-bottom sticky-top">
			<div class="container-fluid d-flex align-items-center">
				<h1 class="d-flex align-items-center fs-4 text-white fw-bold mb-0">Hat<span class="fw-light" style="margin-left:2px;">Tip</span></h1>
				<a href="https://github.com/jdmdigital/hat-tip" class="ms-auto link-light"><span class="d-none d-sm-inline">GitHub</span><span class="icon-logout ms-2"></span></a>
			</div>
		</header>
		<main>
			<section class="py-5 text-center container-fluid">
				<h2 class="display-1">Hat Tip</h2>
				<p class="lead">A super-simple, super-light notification bar using jQuery and British humor.</p>
				<p><a href="https://github.com/jdmdigital/hat-tip" class="btn btn-primary me-3">GitHub Repo</a><a href="#" id="refresh" class="btn btn-secondary">Show Charts</a></p>
			</section>
			<div class="py-4 bg-light container-fluid">
				<div class="row">
					<div class="col-12">
						<div class="card shadow-sm">
							<div class="card-body">
								<button type="button" class="btn btn-sm btn-outline-secondary float-end chart-refresh" data-refresh="chart-bellcurve"><span class="icon-loop"></span><span class="d-none d-lg-inline ms-2">Render</span></button>
								<h3 class="card-title">Bell Curve Example</h3>
								<div id="chart-bellcurve" class="charts"></div>
							</div>
						</div>
					</div>
					<div class="col-12 col-lg-6">
						<div class="card shadow-sm">
							<div class="card-body">
								<button type="button" class="btn btn-sm btn-outline-secondary float-end chart-refresh" data-refresh="chart-funnel"><span class="icon-loop"></span><span class="d-none d-lg-inline ms-2">Render</span></button>
								<h3 class="card-title">3D Funnel</h3>
								<div id="chart-funnel" class="charts"></div>
							</div>
						</div>
					</div>
					<div class="col-12 col-lg-6">
						<div class="card shadow-sm">
							<div class="card-body">
								<button type="button" class="btn btn-sm btn-outline-secondary float-end chart-refresh" data-refresh="chart-pie"><span class="icon-loop"></span><span class="d-none d-lg-inline ms-2">Render</span></button>
								<h3 class="card-title">3D Pie</h3>
								<div id="chart-pie" class="charts"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<footer class="text-muted py-3">
			<div class="container-fluid">
				<div class="row">
					<div class="col-6">
						<p class="mb-0">&copy; <?php echo date('Y'); ?> JDM Digital</p>
					</div>
					<div class="col-6 text-end">
						<ul class="list-inline">
							<li class="list-inline-item"><a href="https://jdmdigital.co/about/">About</a></li>
							<li class="list-inline-item"><a href="https://jdmdigital.co/about/">Terms</a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
	</div>
	<div id="hattip" role="alert">
		<span id="msg"></span>
		<button type="button" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	</div>
	
	<script src="js/jquery-3.6.1.min.js" type="text/javascript"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
	
	<script src="https://code.highcharts.com/highcharts.js"></script>
	<script src="https://code.highcharts.com/highcharts-3d.js"></script>
	<script src="https://code.highcharts.com/modules/cylinder.js"></script>
	<script src="https://code.highcharts.com/modules/funnel3d.js"></script>
	<script src="https://code.highcharts.com/modules/histogram-bellcurve.js"></script>
	<script src="https://code.highcharts.com/modules/exporting.js"></script>
	<script src="https://code.highcharts.com/modules/export-data.js"></script>
	<script src="https://code.highcharts.com/modules/accessibility.js"></script>
	<script src="js/hat-tip.js?v=1" type="text/javascript"></script>
	<script src="js/functions.js?v=8" type="text/javascript"></script>
	
	<script> 
		jQuery(document).ready(function(){
			setTimeout(function() {
				hattip_fire('Top of the morning to ya!', 'ht-default');
			}, 4000);

			setTimeout(function() {
				hattip_fire('Pub closed? Nightmare!', 'ht-danger');
			}, 15000);

			setTimeout(function() {
				hattip_fire('Pub is open! Ideal.', 'ht-success');
			}, 17000);
			
			setTimeout(function() {
				hattip_fire('Fancy a clicking on some of them buttons?', 'ht-default');
			}, 21000);
		});
	</script>
</body>
</html>